-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: spotify
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `popularartists`
--

DROP TABLE IF EXISTS `popularartists`;
/*!50001 DROP VIEW IF EXISTS `popularartists`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `popularartists` AS SELECT 
 1 AS `Artist_id`,
 1 AS `Artist_Name`,
 1 AS `Total_Likes`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `playlistdetails`
--

DROP TABLE IF EXISTS `playlistdetails`;
/*!50001 DROP VIEW IF EXISTS `playlistdetails`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `playlistdetails` AS SELECT 
 1 AS `Playlist_ID`,
 1 AS `Playlist_Title`,
 1 AS `Track_id`,
 1 AS `Track_Title`,
 1 AS `Duration_Minutes`,
 1 AS `Duration_Seconds`,
 1 AS `Artist_Name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `userlikes`
--

DROP TABLE IF EXISTS `userlikes`;
/*!50001 DROP VIEW IF EXISTS `userlikes`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `userlikes` AS SELECT 
 1 AS `User_id`,
 1 AS `User_Name`,
 1 AS `Content_type`,
 1 AS `Content_Title`,
 1 AS `Like_date`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `trackdetails`
--

DROP TABLE IF EXISTS `trackdetails`;
/*!50001 DROP VIEW IF EXISTS `trackdetails`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `trackdetails` AS SELECT 
 1 AS `Track_id`,
 1 AS `Track_Title`,
 1 AS `Duration_Minutes`,
 1 AS `Duration_Seconds`,
 1 AS `Track_Release_Date`,
 1 AS `Track_Genre`,
 1 AS `Artist_Name`,
 1 AS `Collection_Title`,
 1 AS `Collection_Type`,
 1 AS `Collection_Release_Date`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `userdetailswithsubscription`
--

DROP TABLE IF EXISTS `userdetailswithsubscription`;
/*!50001 DROP VIEW IF EXISTS `userdetailswithsubscription`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `userdetailswithsubscription` AS SELECT 
 1 AS `User_id`,
 1 AS `User_Name`,
 1 AS `Email`,
 1 AS `Birth_date`,
 1 AS `Location`,
 1 AS `Country`,
 1 AS `FollowerCount`,
 1 AS `FollowingCount`,
 1 AS `Subscription_Type`,
 1 AS `Subscription_Price`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `popularartists`
--

/*!50001 DROP VIEW IF EXISTS `popularartists`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `popularartists` AS select `a`.`Artist_id` AS `Artist_id`,`a`.`Name` AS `Artist_Name`,count(`l`.`Like_id`) AS `Total_Likes` from (`artist` `a` left join `likes` `l` on(((`l`.`Content_type` = 'Artist') and (`l`.`Content_id` = `a`.`Artist_id`)))) group by `a`.`Artist_id`,`a`.`Name` order by `Total_Likes` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `playlistdetails`
--

/*!50001 DROP VIEW IF EXISTS `playlistdetails`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `playlistdetails` AS select `c`.`Collection_id` AS `Playlist_ID`,`c`.`Title` AS `Playlist_Title`,`t`.`Track_id` AS `Track_id`,`t`.`Title` AS `Track_Title`,`t`.`Duration_Minutes` AS `Duration_Minutes`,`t`.`Duration_Seconds` AS `Duration_Seconds`,`a`.`Name` AS `Artist_Name` from (((`collection` `c` join `playlist_track` `pt` on((`c`.`Collection_id` = `pt`.`Collection_id`))) join `track` `t` on((`pt`.`Track_id` = `t`.`Track_id`))) left join `artist` `a` on((`t`.`Artist_id` = `a`.`Artist_id`))) where (`c`.`Type` = 'Playlist') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `userlikes`
--

/*!50001 DROP VIEW IF EXISTS `userlikes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `userlikes` AS select `u`.`User_id` AS `User_id`,`u`.`Name` AS `User_Name`,`l`.`Content_type` AS `Content_type`,(case when (`l`.`Content_type` = 'Track') then `t`.`Title` when (`l`.`Content_type` = 'Album') then `c`.`Title` when (`l`.`Content_type` = 'Playlist') then `c`.`Title` when (`l`.`Content_type` = 'Artist') then `a`.`Name` else 'Unknown' end) AS `Content_Title`,`l`.`Like_date` AS `Like_date` from ((((`likes` `l` left join `user` `u` on((`l`.`User_id` = `u`.`User_id`))) left join `track` `t` on(((`l`.`Content_type` = 'Track') and (`l`.`Content_id` = `t`.`Track_id`)))) left join `collection` `c` on((((`l`.`Content_type` = 'Album') or (`l`.`Content_type` = 'Playlist')) and (`l`.`Content_id` = `c`.`Collection_id`)))) left join `artist` `a` on(((`l`.`Content_type` = 'Artist') and (`l`.`Content_id` = `a`.`Artist_id`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `trackdetails`
--

/*!50001 DROP VIEW IF EXISTS `trackdetails`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `trackdetails` AS select `t`.`Track_id` AS `Track_id`,`t`.`Title` AS `Track_Title`,`t`.`Duration_Minutes` AS `Duration_Minutes`,`t`.`Duration_Seconds` AS `Duration_Seconds`,`t`.`Release_date` AS `Track_Release_Date`,`t`.`Genre` AS `Track_Genre`,`a`.`Name` AS `Artist_Name`,`c`.`Title` AS `Collection_Title`,`c`.`Type` AS `Collection_Type`,`c`.`Release_date` AS `Collection_Release_Date` from ((`track` `t` left join `artist` `a` on((`t`.`Artist_id` = `a`.`Artist_id`))) left join `collection` `c` on((`t`.`Collection_id` = `c`.`Collection_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `userdetailswithsubscription`
--

/*!50001 DROP VIEW IF EXISTS `userdetailswithsubscription`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `userdetailswithsubscription` AS select `u`.`User_id` AS `User_id`,`u`.`Name` AS `User_Name`,`u`.`Email` AS `Email`,`u`.`Birth_date` AS `Birth_date`,`u`.`Location` AS `Location`,`u`.`Country` AS `Country`,`u`.`FollowerCount` AS `FollowerCount`,`u`.`FollowingCount` AS `FollowingCount`,`s`.`Type` AS `Subscription_Type`,`s`.`Price` AS `Subscription_Price` from (`user` `u` left join `subscription` `s` on((`u`.`Subscription_id` = `s`.`Subscription_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-22 10:52:42
