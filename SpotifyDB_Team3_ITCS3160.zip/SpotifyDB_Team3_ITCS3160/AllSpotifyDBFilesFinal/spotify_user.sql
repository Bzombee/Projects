-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: spotify
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `User_id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Birth_date` date DEFAULT NULL,
  `Location` varchar(100) DEFAULT NULL,
  `Subscription_id` int DEFAULT NULL,
  `Country` varchar(100) DEFAULT NULL,
  `FollowerCount` int DEFAULT '0',
  `FollowingCount` int DEFAULT '0',
  `Device_type` varchar(50) DEFAULT NULL,
  `Registration_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`User_id`),
  UNIQUE KEY `Email` (`Email`),
  KEY `Subscription_id` (`Subscription_id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`Subscription_id`) REFERENCES `subscription` (`Subscription_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'John Doe','johndoe@example.com','password123','1990-01-15','New York',1,'USA',50,100,'iPhone','2024-11-22 15:35:08'),(2,'Jane Smith','janesmith@example.com','password456','1985-03-22','Los Angeles',2,'USA',30,70,'Android','2024-11-22 15:35:08'),(3,'Emily Johnson','emilyj@example.com','password789','2000-05-30','Chicago',1,'Canada',15,40,'Windows','2024-11-22 15:35:08'),(4,'Michael Brown','michaelb@example.com','password101','1995-07-19','Miami',3,'USA',100,200,'Mac','2024-11-22 15:35:08'),(5,'Alex Turner','alexturner@example.com','password102','1992-02-15','San Francisco',1,'USA',60,120,'iPhone','2024-11-22 15:35:08'),(6,'Nina Carter','ninacarter@example.com','password103','1996-11-25','Boston',2,'USA',25,55,'Android','2024-11-22 15:35:08'),(7,'Daniel Lee','daniellee@example.com','password104','1998-06-10','Houston',3,'Canada',40,85,'Windows','2024-11-22 15:35:08'),(8,'Sophia Walker','sophiawalker@example.com','password105','1993-09-13','Chicago',1,'USA',110,250,'Mac','2024-11-22 15:35:08'),(9,'Ryan Adams','ryanadams@example.com','password106','1987-12-05','Los Angeles',2,'USA',45,95,'iPhone','2024-11-22 15:35:08'),(10,'Olivia Scott','oliviascott@example.com','password107','1994-04-02','Miami',3,'Canada',70,150,'Android','2024-11-22 15:35:08');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-22 10:52:41
